/*
Dibawah "FROM purchases" tambahkan code untuk mengambil baris dengan
nilai "makanan" dikolom "category" 
*/

SELECT *
FROM purchases
WHERE category = "makanan";