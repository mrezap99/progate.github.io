import React from 'react';

class App extends React.Component {
  render() {
    return (
    	<div>
    	  <h1>Halo, Ninja Ken!</h1>
    	  {/* Tambahkan tag <button> dengan teks "Guru Domba" */}
    	  <button>Guru Domba</button>
    	  
    	  {/* Tambahkan tag <button> dengan teks "Ninja Ken" */}
    	  <button>Ninja Ken</button>
    	  
    	</div>
    );
  }
}

export default App;
