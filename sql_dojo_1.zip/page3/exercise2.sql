/*
dapatkan nama dan harga setiap produk dan
tampilkan secara mengecil berdasarkan harga
*/
SELECT name, price
FROM items
ORDER BY price DESC;