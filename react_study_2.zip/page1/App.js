import React from 'react';

class App extends React.Component {
  render() {
    return (
     <div>
        <h1>Hello World</h1>
        <p>Ayo belajar React bersama!</p>
      </div>
    );
  }
}

export default App;
