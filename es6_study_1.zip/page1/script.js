console.log("Selamat datang di ES6 Study I!");
console.log("Ayo belajar bersama Ninja Ken!");
