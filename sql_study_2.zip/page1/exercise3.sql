-- dapatkan baris dari kolom name tanpa duplikat
SELECT DISTINCT(name)
FROM purchases;